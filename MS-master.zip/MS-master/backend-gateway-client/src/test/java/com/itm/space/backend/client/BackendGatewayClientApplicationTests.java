package com.itm.space.backend.client;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BackendGatewayClientApplicationTests {

	@Test
	void contextLoads() {
	}

}
